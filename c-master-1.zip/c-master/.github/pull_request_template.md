<!--------------------------------------------------------

Thanks for contributing to the All ▲lgorithms Project

Make sure you fill the require information
---------------------------------------------------------->

This pull request is: <!-- THIS IS REQUIRE -->

<!-- Mark one by adding an [x] -->

- [ ] A new Algorithm
- [ ] An update to an existing algorithm.
- [ ] An error fix
- [ ] Other (Describe below*)

This pull request fixes:

<!-- Enter the issue number which this pull request fixes -->

**Changes:**

<!-- Make sure you follow the contributing and code of conduct of this project -->
