
int
main()
{
	int (((p)));

	p = 0;
	return p;
}
