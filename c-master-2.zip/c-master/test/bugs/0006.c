
void *
foo()
{
	return 0;
}

int
main()
{
	return 0;
}
