
static int x = 0;
static int
foo()
{
	return x;
}

int
main()
{
	return foo();
}
