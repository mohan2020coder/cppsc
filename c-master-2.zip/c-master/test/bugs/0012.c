abort();
main() {
  int b;
  b = 1080377166;
  if (b != 1080377166)
    abort();
}
