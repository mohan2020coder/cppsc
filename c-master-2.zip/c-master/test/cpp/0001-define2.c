#define x x

int
main()
{
	int x;

	x = 0;
	return x;
}

