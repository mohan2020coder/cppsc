
int x[3] = {1, 2, 3};

int
main()
{
	if(x[0] != 1) 
		return 1;
	if(x[1] != 2) 
		return 2;
	if(x[2] != 3) 
		return 3;
	return 0;
}
