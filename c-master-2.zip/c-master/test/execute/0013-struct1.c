struct T {
	int x;
	int y;
};

int
main()
{
	struct T v;
	
	v.y = 0;
	return v.y;
}
