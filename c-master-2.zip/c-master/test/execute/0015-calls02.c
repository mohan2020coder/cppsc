
int
foo(int a, int b)
{
    return a + b;
}

int
main()
{
    return foo(1, 2) - 3;
}
