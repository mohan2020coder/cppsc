/*
PATTERN: redefinition
PATTERN: c:7:
*/

int x = 0;
int x = 1;

