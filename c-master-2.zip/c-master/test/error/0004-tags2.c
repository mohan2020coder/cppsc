/*
PATTERN: tag
PATTERN: c:7:
*/

struct X;
enum   X;
