/*
PATTERN: incomplete
PATTERN: c:12:
*/

int
main()
{
	{
		struct X {};
	}
	struct X x;
	return 0;
}
