/*
PATTERN: c:10
PATTERN: lvalue
*/
int
main()
{
	int *p;	
	
	p = &2;
	return 0;
}
