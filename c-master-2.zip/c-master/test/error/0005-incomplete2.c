/*
PATTERN: incomplete
PATTERN: c:10:
*/

struct X x;

int main()
{
	return x.v;
}

struct X {int v;};
