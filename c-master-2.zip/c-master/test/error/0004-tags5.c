/*
PATTERN: incomplete
PATTERN: c:7:
*/

struct X;
struct X { struct X x; };
