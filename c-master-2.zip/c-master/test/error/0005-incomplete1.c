/*
PATTERN: incomplete
PATTERN: c:10:
*/

struct X;

int main()
{
	struct X x;
	return 0;
}

struct X {int v;};
