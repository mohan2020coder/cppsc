/*
PATTERN: redefinition
PATTERN: c:7:
*/

#define X Y
#define X Z


