
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, long n);
long strlen(const char *s);
char *strncpy(char *dest, const char *src, long n);
