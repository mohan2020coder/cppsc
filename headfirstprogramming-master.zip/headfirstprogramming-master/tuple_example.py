#!/usr/bin/python3

dimensions = (200,50)

print(dimensions[0])
print(dimensions[1])

for dimension in dimensions:
    print(dimension)

dimensions = (400,100)
for dimension in dimensions:
    print(dimension)

