#!/usr/bin/python3

def display_message():
    print("I'm learning about functions!")

display_message()
