#!/usr/bin/python3

print("Languages:\n\tPython\n\tC\n\tJavaScript")

