#!/usr/bin/python3

def favorite_book(title):
    print("One of my favorite books is: " + title.title())

favorite_book("The Moon is a Harsh Mistress")
favorite_book("Sixth Column")

