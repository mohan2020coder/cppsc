#!/usr/bin/python3

a = input("How old are you? ")
age = int(a)

if(age >= 18):
    print("You are old enough to vote!")
else:
    print("You are not old enough to vote!")
print("But there really is no point in voting")

