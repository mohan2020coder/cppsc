#!/usr/bin/python3

name = 'willard'

print("Hello " + name.title() + ", would you like to learn some Python today?")

print(name.title())
print(name.upper())
print(name.lower())

famous_person = '   ozzy ozbourne   \n\t'
quote = famous_person.strip().title() + ' once said, "Of all the things I\'ve lost, I miss my mind the most.'

print(quote)

