#include <stdio.h>

void fortune_cookie(char msg[])
{
    printf("Message reads: %s\n", msg);
}

int main()
{
    char quote[] = "Cookies make you fat";
    fortune_cookie(quote);
}
