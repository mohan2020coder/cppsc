#include <stdio.h>

int main()
{
  puts("C Rocks!");
  return 0;
}
