 int main()
 {
   char search_for[80];
   printf("Search for: ");
   fgets(search_for, 80, stdin);
   find_track();
   return 0;
 }
 int main()
 {
   char search_for[80];
   printf("Search for: ");
   fgets(search_for, 80, stdin);
   find_track(search_for);
   return 0;
 }
 int main()
 {
   char search_for[80];
   printf("Search for: ");
   fgets(search_for, 79, stdin);
   find_track(search_for);
   return 0;
 }
 int main()
 {
   char search_for[80];
   printf("Search for: ");
   scanf(search_for, 80, stdin);
   find_track(search_for);
   return 0;
 }
