<center><h3>Circular Buffer</h3></center>
<hr />

A fixed data structure written in c with generic items to hold.  The structure 
is usefull in cases when structures are rather big and/or need to ensure 
they don't get too big.