<center><h3>C</h3></center>
<hr />

C programming libraries, tutorials, and guides.

These programs are meant to help others get started quicker 
on their own projects and also help them understand certain 
coding techniques and ideas.

Do with them what you want and feel free to send updates or 
improvements or ideas.
