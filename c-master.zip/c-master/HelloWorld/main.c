#include <stdio.h>

/*
 * @author jelathro
 * @date 2/18/13
 * 
 * Print "Hello, World!" to the console
 */
int main(void){
    printf("Hello, World!\n");
    return 0;
}
